/*
  twi.h - TWI/I2C library for Wiring & Arduino
  Copyright (c) 2006 Nicholas Zambetti.  All right reserved.

  This library is free software; you can redistribute it and/or
  modify it under the terms of the GNU Lesser General Public
  License as published by the Free Software Foundation; either
  version 2.1 of the License, or (at your option) any later version.

  This library is distributed in the hope that it will be useful,
  but WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
  Lesser General Public License for more details.

  You should have received a copy of the GNU Lesser General Public
  License along with this library; if not, write to the Free Software
  Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
*/

#ifndef twi1_h
#define twi1_h

  #include <inttypes.h>

  //#define ATMEGA8
  
  #ifdef TW_STATUS_MASK1
    #undef TW_STATUS_MASK1
  #endif
  #define TW_STATUS_MASK1 (_BV(TWS17)| _BV(TWS16)| _BV(TWS15)| _BV(TWS14)| _BV(TWS13)) 

  #ifndef TWI_FREQ
  #define TWI_FREQ 100000L
  #endif

  #ifndef TWI_BUFFER_LENGTH
  #define TWI_BUFFER_LENGTH 32
  #endif

  #define TWI_READY 0
  #define TWI_MRX   1
  #define TWI_MTX   2
  #define TWI_SRX   3
  #define TWI_STX   4
  
  void twi_init1(void);
  void twi_disable1(void);
  void twi_setAddress1(uint8_t);
  uint8_t twi_readFrom1(uint8_t, uint8_t*, uint8_t, uint8_t);
  uint8_t twi_writeTo1(uint8_t, uint8_t*, uint8_t, uint8_t, uint8_t);
  uint8_t twi_transmit1(const uint8_t*, uint8_t);
  void twi_attachSlaveRxEvent1( void (*)(uint8_t*, int) );
  void twi_attachSlaveTxEvent1( void (*)(void) );
  void twi_reply1(uint8_t);
  void twi_stop1(void);
  void twi_releaseBus1(void);

#endif

